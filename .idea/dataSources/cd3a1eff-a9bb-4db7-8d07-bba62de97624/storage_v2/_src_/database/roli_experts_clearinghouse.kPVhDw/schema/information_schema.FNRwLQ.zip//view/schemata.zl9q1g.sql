CREATE VIEW schemata(catalog_name, schema_name, schema_owner, default_character_set_catalog,
                     default_character_set_schema, default_character_set_name, sql_path) AS
SELECT (current_database())::information_schema.SQL_IDENTIFIER      AS catalog_name,
       (n.nspname)::information_schema.SQL_IDENTIFIER               AS schema_name,
       (u.rolname)::information_schema.SQL_IDENTIFIER               AS schema_owner,
       (NULL::CHARACTER VARYING)::information_schema.SQL_IDENTIFIER AS default_character_set_catalog,
       (NULL::CHARACTER VARYING)::information_schema.SQL_IDENTIFIER AS default_character_set_schema,
       (NULL::CHARACTER VARYING)::information_schema.SQL_IDENTIFIER AS default_character_set_name,
       (NULL::CHARACTER VARYING)::information_schema.CHARACTER_DATA AS sql_path
FROM pg_namespace n,
     pg_authid u
WHERE ((n.nspowner = u.oid) AND
       (pg_has_role(n.nspowner, 'USAGE'::TEXT) OR has_schema_privilege(n.oid, 'CREATE, USAGE'::TEXT)));

ALTER TABLE schemata
    OWNER TO postgres;

