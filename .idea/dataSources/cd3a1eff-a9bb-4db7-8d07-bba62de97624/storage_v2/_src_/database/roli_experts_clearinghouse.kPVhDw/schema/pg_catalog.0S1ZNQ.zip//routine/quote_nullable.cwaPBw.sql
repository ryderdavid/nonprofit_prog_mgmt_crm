CREATE FUNCTION quote_nullable(anyelement) RETURNS text
    STABLE
    PARALLEL SAFE
    COST 1
    LANGUAGE SQL
AS
$$
select pg_catalog.quote_nullable($1::pg_catalog.text)
$$;

COMMENT ON FUNCTION quote_nullable(ANYELEMENT) IS 'quote a possibly-null data value for usage in a querystring';

ALTER FUNCTION quote_nullable(ANYELEMENT) OWNER TO postgres;

