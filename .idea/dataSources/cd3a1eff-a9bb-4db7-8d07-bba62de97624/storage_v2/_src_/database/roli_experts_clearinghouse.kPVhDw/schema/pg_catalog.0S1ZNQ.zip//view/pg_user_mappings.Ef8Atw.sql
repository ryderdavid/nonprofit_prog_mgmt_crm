CREATE VIEW pg_user_mappings(umid, srvid, srvname, umuser, usename, umoptions) AS
SELECT u.oid   AS umid,
       s.oid   AS srvid,
       s.srvname,
       u.umuser,
       CASE
           WHEN (u.umuser = (0)::OID) THEN 'public'::NAME
           ELSE a.rolname
           END AS usename,
       CASE
           WHEN (((u.umuser <> (0)::OID) AND (a.rolname = CURRENT_USER) AND
                  (pg_has_role(s.srvowner, 'USAGE'::TEXT) OR has_server_privilege(s.oid, 'USAGE'::TEXT))) OR
                 ((u.umuser = (0)::OID) AND pg_has_role(s.srvowner, 'USAGE'::TEXT)) OR (SELECT pg_authid.rolsuper
                                                                                        FROM pg_authid
                                                                                        WHERE (pg_authid.rolname = CURRENT_USER)))
               THEN u.umoptions
           ELSE NULL::TEXT[]
           END AS umoptions
FROM ((pg_user_mapping u
    JOIN pg_foreign_server s ON ((u.umserver = s.oid)))
         LEFT JOIN pg_authid a ON ((a.oid = u.umuser)));

ALTER TABLE pg_user_mappings
    OWNER TO postgres;

