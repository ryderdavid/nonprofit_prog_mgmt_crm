CREATE VIEW check_constraint_routine_usage(constraint_catalog, constraint_schema, constraint_name, specific_catalog,
                                           specific_schema, specific_name) AS
SELECT (current_database())::information_schema.SQL_IDENTIFIER                                  AS constraint_catalog,
       (nc.nspname)::information_schema.SQL_IDENTIFIER                                          AS constraint_schema,
       (c.conname)::information_schema.SQL_IDENTIFIER                                           AS constraint_name,
       (current_database())::information_schema.SQL_IDENTIFIER                                  AS specific_catalog,
       (np.nspname)::information_schema.SQL_IDENTIFIER                                          AS specific_schema,
       ((((p.proname)::TEXT || '_'::TEXT) || (p.oid)::TEXT))::information_schema.SQL_IDENTIFIER AS specific_name
FROM pg_namespace nc,
     pg_constraint c,
     pg_depend d,
     pg_proc p,
     pg_namespace np
WHERE ((nc.oid = c.connamespace) AND (c.contype = 'c'::"char") AND (c.oid = d.objid) AND
       (d.classid = ('pg_constraint'::REGCLASS)::OID) AND (d.refobjid = p.oid) AND
       (d.refclassid = ('pg_proc'::REGCLASS)::OID) AND (p.pronamespace = np.oid) AND
       pg_has_role(p.proowner, 'USAGE'::TEXT));

ALTER TABLE check_constraint_routine_usage
    OWNER TO postgres;

