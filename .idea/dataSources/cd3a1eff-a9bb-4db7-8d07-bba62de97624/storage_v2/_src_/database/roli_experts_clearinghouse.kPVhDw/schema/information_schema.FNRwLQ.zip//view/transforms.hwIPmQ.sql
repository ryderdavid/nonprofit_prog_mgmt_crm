CREATE VIEW transforms(udt_catalog, udt_schema, udt_name, specific_catalog, specific_schema, specific_name, group_name,
                       transform_type) AS
    SELECT (current_database())::information_schema.SQL_IDENTIFIER                                  AS udt_catalog,
           (nt.nspname)::information_schema.SQL_IDENTIFIER                                          AS udt_schema,
           (t.typname)::information_schema.SQL_IDENTIFIER                                           AS udt_name,
           (current_database())::information_schema.SQL_IDENTIFIER                                  AS specific_catalog,
           (np.nspname)::information_schema.SQL_IDENTIFIER                                          AS specific_schema,
           ((((p.proname)::TEXT || '_'::TEXT) || (p.oid)::TEXT))::information_schema.SQL_IDENTIFIER AS specific_name,
           (l.lanname)::information_schema.SQL_IDENTIFIER                                           AS group_name,
           ('FROM SQL'::CHARACTER VARYING)::information_schema.CHARACTER_DATA                       AS transform_type
    FROM (((((pg_type t
        JOIN pg_transform x ON ((t.oid = x.trftype)))
        JOIN pg_language l ON ((x.trflang = l.oid)))
        JOIN pg_proc p ON (((x.trffromsql)::OID = p.oid)))
        JOIN pg_namespace nt ON ((t.typnamespace = nt.oid)))
             JOIN pg_namespace np ON ((p.pronamespace = np.oid)))
    UNION
    SELECT (current_database())::information_schema.SQL_IDENTIFIER                                  AS udt_catalog,
           (nt.nspname)::information_schema.SQL_IDENTIFIER                                          AS udt_schema,
           (t.typname)::information_schema.SQL_IDENTIFIER                                           AS udt_name,
           (current_database())::information_schema.SQL_IDENTIFIER                                  AS specific_catalog,
           (np.nspname)::information_schema.SQL_IDENTIFIER                                          AS specific_schema,
           ((((p.proname)::TEXT || '_'::TEXT) || (p.oid)::TEXT))::information_schema.SQL_IDENTIFIER AS specific_name,
           (l.lanname)::information_schema.SQL_IDENTIFIER                                           AS group_name,
           ('TO SQL'::CHARACTER VARYING)::information_schema.CHARACTER_DATA                         AS transform_type
    FROM (((((pg_type t
        JOIN pg_transform x ON ((t.oid = x.trftype)))
        JOIN pg_language l ON ((x.trflang = l.oid)))
        JOIN pg_proc p ON (((x.trftosql)::OID = p.oid)))
        JOIN pg_namespace nt ON ((t.typnamespace = nt.oid)))
             JOIN pg_namespace np ON ((p.pronamespace = np.oid)))
    ORDER BY 1, 2, 3, 7, 8;

ALTER TABLE transforms
    OWNER TO postgres;

