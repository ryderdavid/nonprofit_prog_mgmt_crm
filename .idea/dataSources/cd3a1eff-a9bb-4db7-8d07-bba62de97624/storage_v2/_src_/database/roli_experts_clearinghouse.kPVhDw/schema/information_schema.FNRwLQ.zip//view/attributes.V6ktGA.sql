CREATE VIEW attributes(udt_catalog, udt_schema, udt_name, attribute_name, ordinal_position, attribute_default,
                       is_nullable, data_type, character_maximum_length, character_octet_length, character_set_catalog,
                       character_set_schema, character_set_name, collation_catalog, collation_schema, collation_name,
                       numeric_precision, numeric_precision_radix, numeric_scale, datetime_precision, interval_type,
                       interval_precision, attribute_udt_catalog, attribute_udt_schema, attribute_udt_name,
                       scope_catalog, scope_schema, scope_name, maximum_cardinality, dtd_identifier,
                       is_derived_reference_attribute) AS
SELECT (current_database())::information_schema.SQL_IDENTIFIER                                                                           AS udt_catalog,
       (nc.nspname)::information_schema.SQL_IDENTIFIER                                                                                   AS udt_schema,
       (c.relname)::information_schema.SQL_IDENTIFIER                                                                                    AS udt_name,
       (a.attname)::information_schema.SQL_IDENTIFIER                                                                                    AS attribute_name,
       (a.attnum)::information_schema.CARDINAL_NUMBER                                                                                    AS ordinal_position,
       (pg_get_expr(ad.adbin, ad.adrelid))::information_schema.CHARACTER_DATA                                                            AS attribute_default,
       (
           CASE
               WHEN (a.attnotnull OR ((t.typtype = 'd'::"char") AND t.typnotnull)) THEN 'NO'::TEXT
               ELSE 'YES'::TEXT
               END)::information_schema.YES_OR_NO                                                                                        AS is_nullable,
       (
           CASE
               WHEN ((t.typelem <> (0)::OID) AND (t.typlen = '-1'::INTEGER)) THEN 'ARRAY'::TEXT
               WHEN (nt.nspname = 'pg_catalog'::NAME) THEN format_type(a.atttypid, NULL::INTEGER)
               ELSE 'USER-DEFINED'::TEXT
               END)::information_schema.CHARACTER_DATA                                                                                   AS data_type,
       (information_schema._pg_char_max_length(information_schema._pg_truetypid(a.*, t.*),
                                               information_schema._pg_truetypmod(a.*, t.*)))::information_schema.CARDINAL_NUMBER         AS character_maximum_length,
       (information_schema._pg_char_octet_length(information_schema._pg_truetypid(a.*, t.*),
                                                 information_schema._pg_truetypmod(a.*, t.*)))::information_schema.CARDINAL_NUMBER       AS character_octet_length,
       (NULL::CHARACTER VARYING)::information_schema.SQL_IDENTIFIER                                                                      AS character_set_catalog,
       (NULL::CHARACTER VARYING)::information_schema.SQL_IDENTIFIER                                                                      AS character_set_schema,
       (NULL::CHARACTER VARYING)::information_schema.SQL_IDENTIFIER                                                                      AS character_set_name,
       (
           CASE
               WHEN (nco.nspname IS NOT NULL) THEN current_database()
               ELSE NULL::NAME
               END)::information_schema.SQL_IDENTIFIER                                                                                   AS collation_catalog,
       (nco.nspname)::information_schema.SQL_IDENTIFIER                                                                                  AS collation_schema,
       (co.collname)::information_schema.SQL_IDENTIFIER                                                                                  AS collation_name,
       (information_schema._pg_numeric_precision(information_schema._pg_truetypid(a.*, t.*),
                                                 information_schema._pg_truetypmod(a.*, t.*)))::information_schema.CARDINAL_NUMBER       AS numeric_precision,
       (information_schema._pg_numeric_precision_radix(information_schema._pg_truetypid(a.*, t.*),
                                                       information_schema._pg_truetypmod(a.*, t.*)))::information_schema.CARDINAL_NUMBER AS numeric_precision_radix,
       (information_schema._pg_numeric_scale(information_schema._pg_truetypid(a.*, t.*),
                                             information_schema._pg_truetypmod(a.*, t.*)))::information_schema.CARDINAL_NUMBER           AS numeric_scale,
       (information_schema._pg_datetime_precision(information_schema._pg_truetypid(a.*, t.*),
                                                  information_schema._pg_truetypmod(a.*, t.*)))::information_schema.CARDINAL_NUMBER      AS datetime_precision,
       (information_schema._pg_interval_type(information_schema._pg_truetypid(a.*, t.*),
                                             information_schema._pg_truetypmod(a.*, t.*)))::information_schema.CHARACTER_DATA            AS interval_type,
       (NULL::INTEGER)::information_schema.CARDINAL_NUMBER                                                                               AS interval_precision,
       (current_database())::information_schema.SQL_IDENTIFIER                                                                           AS attribute_udt_catalog,
       (nt.nspname)::information_schema.SQL_IDENTIFIER                                                                                   AS attribute_udt_schema,
       (t.typname)::information_schema.SQL_IDENTIFIER                                                                                    AS attribute_udt_name,
       (NULL::CHARACTER VARYING)::information_schema.SQL_IDENTIFIER                                                                      AS scope_catalog,
       (NULL::CHARACTER VARYING)::information_schema.SQL_IDENTIFIER                                                                      AS scope_schema,
       (NULL::CHARACTER VARYING)::information_schema.SQL_IDENTIFIER                                                                      AS scope_name,
       (NULL::INTEGER)::information_schema.CARDINAL_NUMBER                                                                               AS maximum_cardinality,
       (a.attnum)::information_schema.SQL_IDENTIFIER                                                                                     AS dtd_identifier,
       ('NO'::CHARACTER VARYING)::information_schema.YES_OR_NO                                                                           AS is_derived_reference_attribute
FROM ((((pg_attribute a
    LEFT JOIN pg_attrdef ad ON (((a.attrelid = ad.adrelid) AND (a.attnum = ad.adnum))))
    JOIN (pg_class c
        JOIN pg_namespace nc ON ((c.relnamespace = nc.oid))) ON ((a.attrelid = c.oid)))
    JOIN (pg_type t
        JOIN pg_namespace nt ON ((t.typnamespace = nt.oid))) ON ((a.atttypid = t.oid)))
         LEFT JOIN (pg_collation co
    JOIN pg_namespace nco ON ((co.collnamespace = nco.oid))) ON (((a.attcollation = co.oid) AND
                                                                  ((nco.nspname <> 'pg_catalog'::NAME) OR
                                                                   (co.collname <> 'default'::NAME)))))
WHERE ((a.attnum > 0) AND (NOT a.attisdropped) AND (c.relkind = 'c'::"char") AND
       (pg_has_role(c.relowner, 'USAGE'::TEXT) OR has_type_privilege(c.reltype, 'USAGE'::TEXT)));

ALTER TABLE attributes
    OWNER TO postgres;

