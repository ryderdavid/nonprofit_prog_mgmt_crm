CREATE VIEW foreign_tables(foreign_table_catalog, foreign_table_schema, foreign_table_name, foreign_server_catalog,
                           foreign_server_name) AS
SELECT _pg_foreign_tables.foreign_table_catalog,
       _pg_foreign_tables.foreign_table_schema,
       _pg_foreign_tables.foreign_table_name,
       _pg_foreign_tables.foreign_server_catalog,
       _pg_foreign_tables.foreign_server_name
FROM information_schema._pg_foreign_tables;

ALTER TABLE foreign_tables
    OWNER TO postgres;

