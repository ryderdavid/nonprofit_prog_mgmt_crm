CREATE FUNCTION path_contain_pt(path, point) RETURNS boolean
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    COST 1
    LANGUAGE SQL
AS
$$
select pg_catalog.on_ppath($2, $1)
$$;

COMMENT ON FUNCTION path_contain_pt(PATH, POINT) IS 'implementation of @> operator';

ALTER FUNCTION path_contain_pt(PATH, POINT) OWNER TO postgres;

