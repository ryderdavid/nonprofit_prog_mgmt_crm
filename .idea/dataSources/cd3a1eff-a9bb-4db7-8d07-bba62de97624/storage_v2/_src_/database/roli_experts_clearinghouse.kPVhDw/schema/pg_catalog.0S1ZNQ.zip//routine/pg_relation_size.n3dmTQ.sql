CREATE FUNCTION pg_relation_size(regclass) RETURNS bigint
    STRICT
    PARALLEL SAFE
    COST 1
    LANGUAGE SQL
AS
$$
select pg_catalog.pg_relation_size($1, 'main')
$$;

COMMENT ON FUNCTION pg_relation_size(REGCLASS) IS 'disk space usage for the main fork of the specified table or index';

ALTER FUNCTION pg_relation_size(REGCLASS) OWNER TO postgres;

