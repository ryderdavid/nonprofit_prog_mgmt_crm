CREATE FUNCTION rpad(text, integer) RETURNS text
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    COST 1
    LANGUAGE SQL
AS
$$
select pg_catalog.rpad($1, $2, ' ')
$$;

COMMENT ON FUNCTION rpad(TEXT, INTEGER) IS 'right-pad string to length';

ALTER FUNCTION rpad(TEXT, INTEGER) OWNER TO postgres;

